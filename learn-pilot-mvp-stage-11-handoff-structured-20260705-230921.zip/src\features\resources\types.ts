export type ResourcesFeatureStatus = "placeholder";
