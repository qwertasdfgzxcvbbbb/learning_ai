@echo off
setlocal

set "ROOT=%~dp0.."
set "NODE_DIR=%ROOT%\.tools\node-v22.23.1-win-x64-install\node-v22.23.1-win-x64"
set "PATH=%NODE_DIR%;%PATH%"

if exist "%ROOT%\.next" (
  echo Clearing Next.js dev cache...
  rmdir /s /q "%ROOT%\.next"
)

call "%NODE_DIR%\npm.cmd" run dev -- --hostname 127.0.0.1 --port 3000
