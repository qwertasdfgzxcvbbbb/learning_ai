# Testing Notes

- Type checking, linting, unit tests, and focused E2E tests are the expected quality gates.
- Vitest covers pure functions, schema validation, and services.
- Playwright will cover the core mobile user path once the flow exists.
