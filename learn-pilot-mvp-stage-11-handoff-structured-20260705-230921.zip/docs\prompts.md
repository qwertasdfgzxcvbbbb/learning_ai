# Prompts

Prompt files will live under `src/server/ai/prompts/`.

During early MVP development, AI responses are mocked to keep development stable and inexpensive.
