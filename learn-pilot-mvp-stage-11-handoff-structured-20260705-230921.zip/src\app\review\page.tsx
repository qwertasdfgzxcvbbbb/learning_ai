import { EmptyState } from "@/components/feedback/empty-state";
import { MobileShell } from "@/components/layout/mobile-shell";

export default function ReviewPage() {
  return (
    <MobileShell title="复盘" subtitle="阶段 12 会接入真实复盘">
      <EmptyState
        title="复盘入口已预留"
        description="MVP 后续会在这里展示每周任务完成情况、延期任务、跳过任务和 AI 调整建议入口。"
      />
    </MobileShell>
  );
}
