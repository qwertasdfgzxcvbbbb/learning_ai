export type ProgressFeatureStatus = "placeholder";
