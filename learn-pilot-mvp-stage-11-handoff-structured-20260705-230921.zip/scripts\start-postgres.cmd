@echo off
setlocal

set "ROOT=%~dp0.."
set "PG_BIN=%ROOT%\.tools\postgres-17.6\pgsql\bin"
set "PG_DATA=%ROOT%\.tools\postgres-data"

echo Starting local PostgreSQL on port 5432...
echo Keep this window open while developing.
"%PG_BIN%\postgres.exe" -D "%PG_DATA%" -p 5432
