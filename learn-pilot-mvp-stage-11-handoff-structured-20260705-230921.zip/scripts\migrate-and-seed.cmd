@echo off
setlocal

set "ROOT=%~dp0.."
set "NODE_DIR=%ROOT%\.tools\node-v22.23.1-win-x64-install\node-v22.23.1-win-x64"
set "NPM=%NODE_DIR%\npm.cmd"
set "PATH=%NODE_DIR%;%PATH%"

call "%NPM%" run db:migrate
if errorlevel 1 exit /b %errorlevel%

call "%NPM%" run db:seed
if errorlevel 1 exit /b %errorlevel%
